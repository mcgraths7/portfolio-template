"use client";

import { createContext, useContext, useId, type ComponentPropsWithRef, type KeyboardEvent } from "react";

import { cx, rovingIndex, useControllableState } from "../core/index.ts";

interface TabsContextValue {
  value: string;
  setValue: (v: string) => void;
  baseId: string;
}

const TabsContext = createContext<TabsContextValue | null>(null);

function useTabs(component: string): TabsContextValue {
  const ctx = useContext(TabsContext);
  if (!ctx) {
    throw new Error(`<${component}> must be used inside <Tabs>`);
  }
  return ctx;
}

export interface TabsProps extends Omit<ComponentPropsWithRef<"div">, "onChange"> {
  /** Controlled selected tab. */
  value?: string;
  /** Uncontrolled initial tab. */
  defaultValue?: string;
  onValueChange?: (value: string) => void;
  /** Segmented-control look. */
  pills?: boolean;
}

export function Tabs({ value, defaultValue, onValueChange, pills, className, children, ...rest }: TabsProps) {
  const baseId = useId();
  const [selected, setValue] = useControllableState(value, defaultValue ?? "", onValueChange);

  return (
    <div className={cx("sb-tabs", pills && "sb-tabs--pills", className)} {...rest}>
      <TabsContext.Provider value={{ value: selected, setValue, baseId }}>{children}</TabsContext.Provider>
    </div>
  );
}

export function TabList({ className, onKeyDown, ...rest }: ComponentPropsWithRef<"div">) {
  const handleKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    onKeyDown?.(e);
    const tabs = [...e.currentTarget.querySelectorAll<HTMLElement>('[role="tab"]:not(:disabled)')];
    const current = tabs.indexOf(document.activeElement as HTMLElement);
    if (current === -1) {
      return;
    }
    const next = rovingIndex(e.key, current, tabs.length, "both");
    if (next === null) {
      return;
    }
    e.preventDefault();
    tabs[next]?.focus();
    tabs[next]?.click();
  };

  return <div role="tablist" className={cx("sb-tabs__list", className)} onKeyDown={handleKeyDown} {...rest} />;
}

export interface TabProps extends ComponentPropsWithRef<"button"> {
  value: string;
}

export function Tab({ value, className, onClick, ...rest }: TabProps) {
  const ctx = useTabs("Tab");
  const selected = ctx.value === value;
  return (
    <button
      type="button"
      role="tab"
      id={`${ctx.baseId}-tab-${value}`}
      aria-controls={`${ctx.baseId}-panel-${value}`}
      aria-selected={selected}
      tabIndex={selected ? 0 : -1}
      className={cx("sb-tabs__tab", className)}
      onClick={(e) => {
        onClick?.(e);
        ctx.setValue(value);
      }}
      {...rest}
    />
  );
}

export interface TabPanelProps extends ComponentPropsWithRef<"div"> {
  value: string;
}

export function TabPanel({ value, className, ...rest }: TabPanelProps) {
  const ctx = useTabs("TabPanel");
  const selected = ctx.value === value;
  return (
    <div
      role="tabpanel"
      id={`${ctx.baseId}-panel-${value}`}
      aria-labelledby={`${ctx.baseId}-tab-${value}`}
      hidden={!selected}
      className={cx("sb-tabs__panel", className)}
      {...rest}
    />
  );
}
